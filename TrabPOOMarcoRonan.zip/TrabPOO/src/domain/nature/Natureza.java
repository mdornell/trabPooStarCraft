package domain.nature;

public abstract class Natureza {
    
}
