package domain.nature;

public class Machanic extends Natureza{
    
    public Machanic(){
        
    }
}
